
package com.mycompany.lab_2;

public class Calculo {
    
    public Cliente CalculoMonto(Cliente C, int minutos){
        int monto = C.getPlan().getCosto_mantencion() + (C.getPlan().getCosto_minuto()*minutos);
        C.setMonto_total(monto);
        return C;
        }
    
}
