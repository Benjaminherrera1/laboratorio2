package com.mycompany.lab_2;
import java.util.Scanner;

public class Lab_2 {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        
        Plan P = new Plan("Preferencial",15000,80,0);
        Plan N = new Plan("Normal",7000,120,0);
        
        String nombre_cliente="";
        int monto_total=0;
        
        Cliente C = new Cliente(nombre_cliente,monto_total);
        Calculo ca = new Calculo();
        
        int plan, minutos, continuar;
        
        do{
            System.out.println("Ingrese el nombre del cliente: ");
            C.setNombre_cliente(leer.next());
            
            System.out.println("Ingrese el tipo de plan");
            System.out.println("Ingrese 1 para Preferencial o 2 para Normal: ");
            plan = leer.nextInt();             
            
            if (plan == 1){
            C.setPlan(P);
            P.setCantidad_cliente(P.getCantidad_cliente()+1);
            }
            
            else{
            C.setPlan(N);
            N.setCantidad_cliente(N.getCantidad_cliente()+1);
            }
            
            System.out.println("Ingrese los minutos consumidos: ");
            minutos = leer.nextInt();
            
            ca.CalculoMonto(C, minutos);
            System.out.println("Al cliente "+C.getNombre_cliente()+" le corresponde el plan "+C.getPlan().getTipo_plan()+" del cual ha consumido "+minutos+ " minutos, debiendo de pagar "+C.getMonto_total()+" pesos");
            
            System.out.println("Para continuar ingrese 1");
            System.out.println("Para salir ingrese 0");
            continuar = leer.nextInt();
            
            while((continuar == 1) && (continuar == 0)){
            System.out.println("Error Debe ingresar 1 o 0");
            System.out.println("Desea continuar ingrese Si, para salir ingrese No");            
            continuar = leer.nextInt();
            }
        }while(continuar == 1);
        
        System.out.println("El plan "+P.getTipo_plan()+" tiene "+P.getCantidad_cliente()+" clientes");
        System.out.println("El plan "+N.getTipo_plan()+" tiene "+N.getCantidad_cliente()+" clientes");
        
    }
}

