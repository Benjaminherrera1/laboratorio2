package com.mycompany.lab_2;


public class Plan {
    private String tipo_plan;
    private int costo_mantencion, costo_minuto, cantidad_cliente;

    public Plan(String tipo_plan, int costo_mantencion, int costo_minuto, int cantidad_cliente) {
        this.tipo_plan = tipo_plan;
        this.costo_mantencion = costo_mantencion;
        this.costo_minuto = costo_minuto;
        this.cantidad_cliente = cantidad_cliente;
    }

    public String getTipo_plan() {
        return tipo_plan;
    }

    public void setTipo_plan(String tipo_plan) {
        this.tipo_plan = tipo_plan;
    }

    public int getCosto_mantencion() {
        return costo_mantencion;
    }

    public void setCosto_mantencion(int costo_mantencion) {
        this.costo_mantencion = costo_mantencion;
    }

    public int getCosto_minuto() {
        return costo_minuto;
    }

    public void setCosto_minuto(int costo_minuto) {
        this.costo_minuto = costo_minuto;
    }

    public int getCantidad_cliente() {
        return cantidad_cliente;
    }

    public void setCantidad_cliente(int cantidad_cliente) {
        this.cantidad_cliente = cantidad_cliente;
    }
    
     
}
