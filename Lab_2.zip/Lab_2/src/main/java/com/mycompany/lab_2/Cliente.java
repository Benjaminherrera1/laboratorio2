package com.mycompany.lab_2;


public class Cliente {
    private String nombre_cliente;
    private Plan plan;
    private int monto_total;

    public Cliente(String nombre_cliente, int monto_total) {
        this.nombre_cliente = nombre_cliente;
        this.monto_total = monto_total;
    }

    public String getNombre_cliente() {
        return nombre_cliente;
    }

    public void setNombre_cliente(String nombre_cliente) {
        this.nombre_cliente = nombre_cliente;
    }

    public Plan getPlan() {
        return plan;
    }

    public void setPlan(Plan plan) {
        this.plan = plan;
    }

    public int getMonto_total() {
        return monto_total;
    }

    public void setMonto_total(int monto_total) {
        this.monto_total = monto_total;
    }
    
    

   

    
    
    
}
